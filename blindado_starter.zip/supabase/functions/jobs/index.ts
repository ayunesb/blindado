
import { serve } from "serve";
import { createClient } from "supabase";

function json(data: any, status = 200) {
  return new Response(JSON.stringify(data), { status, headers: { "Content-Type": "application/json" }});
}

serve(async (req) => {
  const url = new URL(req.url);
  const path = url.pathname.split("/").pop();

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  if (req.method === "GET" && path === "list") {
    // list offered assignments for a guard (requires guard_id param for now)
    const guard_id = url.searchParams.get("guard_id");
    if (!guard_id) return json({ error: "guard_id required" }, 400);
    const { data, error } = await supabase
      .from("assignments").select("*, bookings(*)")
      .eq("guard_id", guard_id).eq("status", "offered");
    if (error) return json({ error: error.message }, 500);
    return json({ jobs: data });
  }

  if (req.method === "POST" && path === "accept") {
    const { assignment_id } = await req.json();
    // first-accept wins (race-safe with status update)
    const { data: current, error: getErr } = await supabase
      .from("assignments").select("*").eq("id", assignment_id).single();
    if (getErr || !current) return json({ error: "assignment not found" }, 404);
    if (current.status !== "offered") return json({ ok: true, status: current.status });

    const { error: updErr } = await supabase
      .from("assignments").update({ status: "accepted" }).eq("id", assignment_id);
    if (updErr) return json({ error: updErr.message }, 500);

    // set booking to assigned
    await supabase.from("bookings").update({ status: "assigned" }).eq("id", current.booking_id);
    return json({ ok: true });
  }

  if (req.method === "POST" && path === "status") {
    const { assignment_id, status } = await req.json();
    const allowed = ["check_in","on_site","in_progress","check_out","completed"];
    if (!allowed.includes(status)) return json({ error: "invalid status" }, 400);
    const { error } = await supabase
      .from("assignments").update({ status }).eq("id", assignment_id);
    if (error) return json({ error: error.message }, 500);
    return json({ ok: true });
  }

  return json({ error: "not found" }, 404);
});
