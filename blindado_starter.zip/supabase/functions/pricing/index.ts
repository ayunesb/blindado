
import { serve } from "serve";

// Simple pricing v1 based on request payload and mocked rules (replace with DB fetch)
serve(async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "POST only" }), { status: 405 });
  }
  const body = await req.json();
  const {
    city, tier = "direct", armed_required = false,
    vehicle_required = false, vehicle_type = null,
    start_ts, end_ts, surge_mult = 1.0
  } = body;

  // Duration (hours)
  const start = new Date(start_ts).getTime();
  const end = new Date(end_ts).getTime();
  const durationHrs = Math.max(0.5, (end - start) / (1000 * 60 * 60));

  // TODO: fetch from pricing_rules where city,tier
  const rules = {
    base_rate_guard: 700, // MXN/hr
    armed_multiplier: 1.5,
    vehicle_rate_suv: 1500,
    vehicle_rate_armored: 3000,
    min_hours: 4
  };

  const hours = Math.max(rules.min_hours, durationHrs);
  let guardTotal = rules.base_rate_guard * hours;
  if (armed_required) guardTotal *= rules.armed_multiplier;

  let vehicleTotal = 0;
  if (vehicle_required) {
    if (vehicle_type === "armored_suv") vehicleTotal = rules.vehicle_rate_armored * hours;
    else vehicleTotal = rules.vehicle_rate_suv * hours;
  }

  const quote = Math.round((guardTotal + vehicleTotal) * surge_mult);
  const preauth = Math.round(quote * 1.1); // 10% buffer

  return new Response(JSON.stringify({
    quote_amount: quote, currency: "MXN",
    min_hours: rules.min_hours, surge_mult, preauth_amount: preauth
  }), { headers: { "Content-Type": "application/json" }});
});
