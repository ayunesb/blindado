# Blindado Admin (Vite + React + Leaflet)

Run: `npm i && npm run dev`.
