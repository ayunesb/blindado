# Blindado Guard (Expo)

Run: `npm i && npm run start` (set EXPO_PUBLIC_API_URL). Replace GUARD_ID.
