# Blindado Client (Expo)

Run: `npm i && npm run start` (set EXPO_PUBLIC_API_URL).
